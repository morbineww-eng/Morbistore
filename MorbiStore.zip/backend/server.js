// server.js — главный файл сервера Morbi Store
const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const cors = require('cors');
const db = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;
// ВАЖНО: поменяй этот секретный ключ на свой перед запуском в реальной жизни
const JWT_SECRET = process.env.JWT_SECRET || 'morbi-store-secret-change-me';

app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// ---------- Настройка загрузки файлов ----------
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    if (file.fieldname === 'apk') cb(null, path.join(__dirname, 'uploads/apks'));
    else cb(null, path.join(__dirname, 'uploads/screenshots'));
  },
  filename: (req, file, cb) => {
    const unique = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, unique + path.extname(file.originalname));
  }
});
const upload = multer({ storage, limits: { fileSize: 200 * 1024 * 1024 } }); // до 200MB

// ---------- Проверка токена (middleware) ----------
function authMiddleware(req, res, next) {
  const header = req.headers['authorization'];
  if (!header) return res.status(401).json({ error: 'Нет токена' });
  const token = header.split(' ')[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Неверный токен' });
  }
}

// ================= АВТОРИЗАЦИЯ =================

app.post('/api/register', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({ error: 'Заполните все поля' });
  const exists = db.prepare('SELECT id FROM users WHERE username = ?').get(username);
  if (exists) return res.status(400).json({ error: 'Такой пользователь уже существует' });

  const hash = bcrypt.hashSync(password, 10);
  const result = db.prepare('INSERT INTO users (username, password) VALUES (?, ?)').run(username, hash);
  const token = jwt.sign({ id: result.lastInsertRowid, username }, JWT_SECRET, { expiresIn: '30d' });
  res.json({ token, username });
});

app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
  if (!user) return res.status(400).json({ error: 'Неверный логин или пароль' });
  if (!bcrypt.compareSync(password, user.password)) return res.status(400).json({ error: 'Неверный логин или пароль' });

  const token = jwt.sign({ id: user.id, username: user.username }, JWT_SECRET, { expiresIn: '30d' });
  res.json({ token, username: user.username, isDeveloper: !!user.is_developer });
});

// ================= ПРИЛОЖЕНИЯ =================

// Список приложений (с фильтром по вкладке и поиском)
app.get('/api/apps', (req, res) => {
  const { tab, search, category } = req.query;
  let query = 'SELECT apps.*, users.username as developer_name FROM apps LEFT JOIN users ON apps.developer_id = users.id WHERE 1=1';
  const params = [];

  if (tab && tab !== 'all') {
    query += ' AND tab = ?';
    params.push(tab);
  }
  if (search) {
    query += ' AND title LIKE ?';
    params.push('%' + search + '%');
  }
  if (category) {
    query += ' AND category = ?';
    params.push(category);
  }
  query += ' ORDER BY created_at DESC';

  const apps = db.prepare(query).all(...params);
  res.json(apps);
});

// Детали одного приложения + скриншоты
app.get('/api/apps/:id', (req, res) => {
  const app_ = db.prepare('SELECT apps.*, users.username as developer_name FROM apps LEFT JOIN users ON apps.developer_id = users.id WHERE apps.id = ?').get(req.params.id);
  if (!app_) return res.status(404).json({ error: 'Приложение не найдено' });
  const screenshots = db.prepare('SELECT * FROM screenshots WHERE app_id = ?').all(req.params.id);
  const reviews = db.prepare('SELECT reviews.*, users.username FROM reviews LEFT JOIN users ON reviews.user_id = users.id WHERE app_id = ? ORDER BY created_at DESC').all(req.params.id);
  res.json({ ...app_, screenshots, reviews });
});

// Загрузка нового приложения (нужен токен = разработчик)
app.post('/api/apps', authMiddleware, upload.fields([
  { name: 'apk', maxCount: 1 },
  { name: 'icon', maxCount: 1 },
  { name: 'screenshots', maxCount: 10 }
]), (req, res) => {
  const { title, description, category, package_name, version } = req.body;
  if (!title || !req.files.apk) return res.status(400).json({ error: 'Укажите название и APK файл' });

  const apkPath = 'uploads/apks/' + req.files.apk[0].filename;
  const iconPath = req.files.icon ? 'uploads/screenshots/' + req.files.icon[0].filename : null;

  // Новые приложения всегда идут в "не проверено" — кроме случая,
  // когда загружает сам владелец магазина (вкладка "Morbi", проверяется вручную в базе)
  const result = db.prepare(`
    INSERT INTO apps (title, description, category, package_name, version, apk_path, icon_path, tab, developer_id)
    VALUES (?, ?, ?, ?, ?, ?, ?, 'unverified', ?)
  `).run(title, description || '', category || '', package_name || '', version || '1.0', apkPath, iconPath, req.user.id);

  const appId = result.lastInsertRowid;

  if (req.files.screenshots) {
    const insertShot = db.prepare('INSERT INTO screenshots (app_id, path) VALUES (?, ?)');
    for (const file of req.files.screenshots) {
      insertShot.run(appId, 'uploads/screenshots/' + file.filename);
    }
  }

  res.json({ id: appId, message: 'Приложение загружено и ожидает проверки' });
});

// Увеличить счётчик скачиваний
app.post('/api/apps/:id/download', (req, res) => {
  db.prepare('UPDATE apps SET downloads = downloads + 1 WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

// ================= ОТЗЫВЫ =================

app.post('/api/apps/:id/reviews', authMiddleware, (req, res) => {
  const { rating, text } = req.body;
  if (!rating) return res.status(400).json({ error: 'Укажите оценку' });
  db.prepare('INSERT INTO reviews (app_id, user_id, rating, text) VALUES (?, ?, ?, ?)')
    .run(req.params.id, req.user.id, rating, text || '');
  res.json({ ok: true });
});

// ================= АДМИН: перенос приложения во вкладку "Morbi" =================
// Простой способ самому пометить своё приложение официальным.
// Используй это только под своим аккаунтом разработчика.
app.post('/api/apps/:id/approve', authMiddleware, (req, res) => {
  const { tab } = req.body; // 'morbi' | 'all' | 'unverified'
  if (!['morbi', 'all', 'unverified'].includes(tab)) return res.status(400).json({ error: 'Неверная вкладка' });
  db.prepare('UPDATE apps SET tab = ? WHERE id = ?').run(tab, req.params.id);
  res.json({ ok: true });
});

app.listen(PORT, () => {
  console.log(`Morbi Store сервер запущен на порту ${PORT}`);
});
