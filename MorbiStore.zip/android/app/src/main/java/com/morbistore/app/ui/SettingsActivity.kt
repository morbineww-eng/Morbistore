package com.morbistore.app.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import com.morbistore.app.MorbiApp
import com.morbistore.app.data.SessionManager
import com.morbistore.app.databinding.ActivitySettingsBinding

class SettingsActivity : BaseActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private lateinit var session: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        session = SessionManager(this)

        // Отметить текущие значения
        when (session.themeMode) {
            "light" -> binding.radioThemeLight.isChecked = true
            "dark" -> binding.radioThemeDark.isChecked = true
            else -> binding.radioThemeSystem.isChecked = true
        }
        when (session.languageMode) {
            "ru" -> binding.radioLangRu.isChecked = true
            "en" -> binding.radioLangEn.isChecked = true
            else -> binding.radioLangSystem.isChecked = true
        }
        binding.switchNotifications.isChecked = session.notificationsEnabled

        binding.radioTheme.setOnCheckedChangeListener { _, checkedId ->
            val mode = when (checkedId) {
                binding.radioThemeLight.id -> "light"
                binding.radioThemeDark.id -> "dark"
                else -> "system"
            }
            session.themeMode = mode
            MorbiApp.applyTheme(mode)
        }

        binding.radioLanguage.setOnCheckedChangeListener { _, checkedId ->
            val mode = when (checkedId) {
                binding.radioLangRu.id -> "ru"
                binding.radioLangEn.id -> "en"
                else -> "system"
            }
            if (mode != session.languageMode) {
                session.languageMode = mode
                // Перезапускаем экраны, чтобы применить новый язык сразу
                val intent = Intent(this, MainActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
            }
        }

        binding.switchNotifications.setOnCheckedChangeListener { _, isChecked ->
            session.notificationsEnabled = isChecked
        }

        binding.btnCheckUpdates.setOnClickListener {
            Toast.makeText(this, "Обновлений не найдено", Toast.LENGTH_SHORT).show()
            // Здесь позже можно сравнить установленные версии с сервером через /api/apps
        }

        binding.btnDeveloperPanel.setOnClickListener {
            if (session.isLoggedIn()) {
                startActivity(Intent(this, UploadActivity::class.java))
            } else {
                Toast.makeText(this, getString(com.morbistore.app.R.string.login_required), Toast.LENGTH_SHORT).show()
                startActivity(Intent(this, LoginActivity::class.java))
            }
        }

        binding.btnLogout.setOnClickListener {
            session.logout()
            Toast.makeText(this, "Вы вышли из аккаунта", Toast.LENGTH_SHORT).show()
        }
    }
}
