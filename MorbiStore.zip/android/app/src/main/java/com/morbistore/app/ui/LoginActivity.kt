package com.morbistore.app.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import com.morbistore.app.data.ApiClient
import com.morbistore.app.data.LoginRequest
import com.morbistore.app.data.SessionManager
import com.morbistore.app.databinding.ActivityLoginBinding
import kotlinx.coroutines.launch

class LoginActivity : BaseActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var session: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
        session = SessionManager(this)

        binding.btnLogin.setOnClickListener { doLogin() }
        binding.btnGoRegister.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
    }

    private fun doLogin() {
        val username = binding.editUsername.text.toString().trim()
        val password = binding.editPassword.text.toString()
        if (username.isEmpty() || password.isEmpty()) return

        lifecycleScope.launch {
            try {
                val response = ApiClient.api.login(LoginRequest(username, password))
                if (response.isSuccessful) {
                    val body = response.body()!!
                    session.token = body.token
                    session.username = body.username
                    Toast.makeText(this@LoginActivity, "Добро пожаловать!", Toast.LENGTH_SHORT).show()
                    finish()
                } else {
                    Toast.makeText(this@LoginActivity, "Неверный логин или пароль", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@LoginActivity, "Сервер недоступен", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
