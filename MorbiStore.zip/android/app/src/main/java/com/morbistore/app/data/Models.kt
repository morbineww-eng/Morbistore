package com.morbistore.app.data

data class AppItem(
    val id: Int,
    val title: String,
    val description: String?,
    val category: String?,
    val package_name: String?,
    val version: String?,
    val apk_path: String,
    val icon_path: String?,
    val tab: String,
    val downloads: Int,
    val developer_name: String?,
    val screenshots: List<Screenshot>? = null,
    val reviews: List<Review>? = null
)

data class Screenshot(
    val id: Int,
    val app_id: Int,
    val path: String
)

data class Review(
    val id: Int,
    val app_id: Int,
    val user_id: Int,
    val username: String?,
    val rating: Int,
    val text: String?,
    val created_at: String?
)

data class AuthResponse(
    val token: String,
    val username: String,
    val isDeveloper: Boolean? = false
)

data class LoginRequest(val username: String, val password: String)
data class ReviewRequest(val rating: Int, val text: String)
