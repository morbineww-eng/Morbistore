package com.morbistore.app.data

import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.*

interface ApiService {

    @POST("api/register")
    suspend fun register(@Body body: LoginRequest): Response<AuthResponse>

    @POST("api/login")
    suspend fun login(@Body body: LoginRequest): Response<AuthResponse>

    @GET("api/apps")
    suspend fun getApps(
        @Query("tab") tab: String?,
        @Query("search") search: String?
    ): Response<List<AppItem>>

    @GET("api/apps/{id}")
    suspend fun getAppDetail(@Path("id") id: Int): Response<AppItem>

    @POST("api/apps/{id}/download")
    suspend fun registerDownload(@Path("id") id: Int): Response<Unit>

    @POST("api/apps/{id}/reviews")
    suspend fun postReview(
        @Path("id") id: Int,
        @Header("Authorization") token: String,
        @Body body: ReviewRequest
    ): Response<Unit>

    @Multipart
    @POST("api/apps")
    suspend fun uploadApp(
        @Header("Authorization") token: String,
        @Part("title") title: RequestBody,
        @Part("description") description: RequestBody,
        @Part("category") category: RequestBody,
        @Part apk: MultipartBody.Part,
        @Part screenshots: List<MultipartBody.Part>
    ): Response<Unit>
}
