package com.morbistore.app.ui

import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter

class MainPagerAdapter(activity: FragmentActivity) : FragmentStateAdapter(activity) {

    val tabs = listOf("morbi", "all", "unverified")
    val fragments = mutableMapOf<Int, AppListFragment>()

    override fun getItemCount() = tabs.size

    override fun createFragment(position: Int): AppListFragment {
        val f = AppListFragment.newInstance(tabs[position])
        fragments[position] = f
        return f
    }
}
