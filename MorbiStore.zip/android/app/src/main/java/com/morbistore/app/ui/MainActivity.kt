package com.morbistore.app.ui

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.widget.SearchView
import com.google.android.material.tabs.TabLayoutMediator
import com.morbistore.app.R
import com.morbistore.app.databinding.ActivityMainBinding

class MainActivity : BaseActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var pagerAdapter: MainPagerAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        pagerAdapter = MainPagerAdapter(this)
        binding.viewPager.adapter = pagerAdapter

        val tabTitles = listOf(
            getString(R.string.tab_morbi),
            getString(R.string.tab_all),
            getString(R.string.tab_unverified)
        )

        TabLayoutMediator(binding.tabLayout, binding.viewPager) { tabItem, position ->
            tabItem.text = tabTitles[position]
        }.attach()

        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                currentFragment()?.search(query)
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                currentFragment()?.search(newText)
                return true
            }
        })
    }

    private fun currentFragment(): AppListFragment? {
        return pagerAdapter.fragments[binding.viewPager.currentItem]
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.action_settings) {
            startActivity(Intent(this, SettingsActivity::class.java))
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}
