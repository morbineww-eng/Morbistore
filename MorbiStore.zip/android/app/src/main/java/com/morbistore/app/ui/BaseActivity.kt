package com.morbistore.app.ui

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import com.morbistore.app.data.LocaleHelper
import com.morbistore.app.data.SessionManager

// Все экраны наследуются от этого класса, чтобы язык применялся везде одинаково
open class BaseActivity : AppCompatActivity() {
    override fun attachBaseContext(newBase: Context) {
        val session = SessionManager(newBase)
        super.attachBaseContext(LocaleHelper.wrap(newBase, session.languageMode))
    }
}
