package com.morbistore.app

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate
import com.morbistore.app.data.SessionManager

class MorbiApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val session = SessionManager(this)
        applyTheme(session.themeMode)
    }

    companion object {
        fun applyTheme(mode: String) {
            when (mode) {
                "light" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                "dark" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                else -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
            }
        }
    }
}
