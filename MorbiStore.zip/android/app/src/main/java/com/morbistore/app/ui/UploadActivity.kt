package com.morbistore.app.ui

import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import com.morbistore.app.data.ApiClient
import com.morbistore.app.data.SessionManager
import com.morbistore.app.databinding.ActivityUploadBinding
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.io.FileOutputStream

class UploadActivity : BaseActivity() {

    private lateinit var binding: ActivityUploadBinding
    private lateinit var session: SessionManager

    private var apkFile: File? = null
    private val screenshotFiles = mutableListOf<File>()

    private val pickApk = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let {
            apkFile = copyUriToCache(it, "upload.apk")
            binding.txtApkName.text = apkFile?.name ?: ""
        }
    }

    private val pickScreenshots = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        screenshotFiles.clear()
        uris.forEachIndexed { index, uri ->
            copyUriToCache(uri, "shot_$index.jpg")?.let { screenshotFiles.add(it) }
        }
        binding.txtScreenshotsCount.text = "${screenshotFiles.size} файлов выбрано"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUploadBinding.inflate(layoutInflater)
        setContentView(binding.root)
        session = SessionManager(this)

        binding.btnSelectApk.setOnClickListener {
            pickApk.launch("application/vnd.android.package-archive")
        }
        binding.btnSelectScreenshots.setOnClickListener {
            pickScreenshots.launch("image/*")
        }
        binding.btnUpload.setOnClickListener { doUpload() }
    }

    private fun copyUriToCache(uri: Uri, name: String): File? {
        return try {
            val input = contentResolver.openInputStream(uri) ?: return null
            val file = File(cacheDir, "${System.currentTimeMillis()}_$name")
            FileOutputStream(file).use { output -> input.copyTo(output) }
            file
        } catch (e: Exception) {
            null
        }
    }

    private fun doUpload() {
        val title = binding.editTitle.text.toString().trim()
        val description = binding.editDescription.text.toString().trim()
        val category = binding.editCategory.text.toString().trim()
        val apk = apkFile

        if (title.isEmpty() || apk == null) {
            Toast.makeText(this, "Укажите название и выберите APK", Toast.LENGTH_SHORT).show()
            return
        }

        val titleBody = title.toRequestBody("text/plain".toMediaTypeOrNull())
        val descBody = description.toRequestBody("text/plain".toMediaTypeOrNull())
        val catBody = category.toRequestBody("text/plain".toMediaTypeOrNull())

        val apkPart = MultipartBody.Part.createFormData(
            "apk", apk.name, apk.asRequestBody("application/vnd.android.package-archive".toMediaTypeOrNull())
        )

        val screenshotParts = screenshotFiles.map { file ->
            MultipartBody.Part.createFormData(
                "screenshots", file.name, file.asRequestBody("image/*".toMediaTypeOrNull())
            )
        }

        lifecycleScope.launch {
            try {
                val response = ApiClient.api.uploadApp(
                    session.authHeader(), titleBody, descBody, catBody, apkPart, screenshotParts
                )
                if (response.isSuccessful) {
                    Toast.makeText(this@UploadActivity, "Приложение отправлено на проверку!", Toast.LENGTH_LONG).show()
                    finish()
                } else {
                    Toast.makeText(this@UploadActivity, "Ошибка загрузки", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@UploadActivity, "Сервер недоступен", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
