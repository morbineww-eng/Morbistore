package com.morbistore.app.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.morbistore.app.data.ApiClient
import com.morbistore.app.data.AppItem
import com.morbistore.app.databinding.ItemAppBinding

class AppAdapter(
    private var items: List<AppItem>,
    private val onClick: (AppItem) -> Unit
) : RecyclerView.Adapter<AppAdapter.AppViewHolder>() {

    inner class AppViewHolder(val binding: ItemAppBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AppViewHolder {
        val binding = ItemAppBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return AppViewHolder(binding)
    }

    override fun onBindViewHolder(holder: AppViewHolder, position: Int) {
        val item = items[position]
        holder.binding.txtTitle.text = item.title
        holder.binding.txtCategory.text = item.category ?: ""
        holder.binding.txtDownloads.text = "${item.downloads}"

        val iconUrl = item.icon_path?.let { ApiClient.BASE_URL + it }
        Glide.with(holder.itemView.context)
            .load(iconUrl)
            .placeholder(android.R.drawable.ic_menu_gallery)
            .into(holder.binding.imgIcon)

        holder.itemView.setOnClickListener { onClick(item) }
    }

    override fun getItemCount() = items.size

    fun updateData(newItems: List<AppItem>) {
        items = newItems
        notifyDataSetChanged()
    }
}
