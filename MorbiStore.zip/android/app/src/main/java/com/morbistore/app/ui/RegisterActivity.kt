package com.morbistore.app.ui

import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import com.morbistore.app.data.ApiClient
import com.morbistore.app.data.LoginRequest
import com.morbistore.app.data.SessionManager
import com.morbistore.app.databinding.ActivityRegisterBinding
import kotlinx.coroutines.launch

class RegisterActivity : BaseActivity() {

    private lateinit var binding: ActivityRegisterBinding
    private lateinit var session: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)
        session = SessionManager(this)

        binding.btnRegister.setOnClickListener { doRegister() }
    }

    private fun doRegister() {
        val username = binding.editUsername.text.toString().trim()
        val password = binding.editPassword.text.toString()
        if (username.isEmpty() || password.isEmpty()) return

        lifecycleScope.launch {
            try {
                val response = ApiClient.api.register(LoginRequest(username, password))
                if (response.isSuccessful) {
                    val body = response.body()!!
                    session.token = body.token
                    session.username = body.username
                    Toast.makeText(this@RegisterActivity, "Аккаунт создан!", Toast.LENGTH_SHORT).show()
                    finish()
                } else {
                    Toast.makeText(this@RegisterActivity, "Такой пользователь уже существует", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@RegisterActivity, "Сервер недоступен", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
