package com.morbistore.app.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.morbistore.app.data.Review
import com.morbistore.app.databinding.ItemReviewBinding

class ReviewAdapter(private val items: List<Review>) :
    RecyclerView.Adapter<ReviewAdapter.ReviewViewHolder>() {

    inner class ReviewViewHolder(val binding: ItemReviewBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ReviewViewHolder {
        val binding = ItemReviewBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ReviewViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ReviewViewHolder, position: Int) {
        val item = items[position]
        holder.binding.txtUsername.text = item.username ?: "—"
        holder.binding.txtRating.text = "★".repeat(item.rating)
        holder.binding.txtReviewText.text = item.text ?: ""
    }

    override fun getItemCount() = items.size
}
