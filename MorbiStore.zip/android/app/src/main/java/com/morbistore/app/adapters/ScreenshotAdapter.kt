package com.morbistore.app.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.morbistore.app.R
import com.morbistore.app.data.ApiClient
import com.morbistore.app.data.Screenshot

class ScreenshotAdapter(private val items: List<Screenshot>) :
    RecyclerView.Adapter<ScreenshotAdapter.ShotViewHolder>() {

    inner class ShotViewHolder(val img: ImageView) : RecyclerView.ViewHolder(img)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ShotViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_screenshot, parent, false) as ImageView
        return ShotViewHolder(view)
    }

    override fun onBindViewHolder(holder: ShotViewHolder, position: Int) {
        val url = ApiClient.BASE_URL + items[position].path
        Glide.with(holder.img.context).load(url).into(holder.img)
    }

    override fun getItemCount() = items.size
}
