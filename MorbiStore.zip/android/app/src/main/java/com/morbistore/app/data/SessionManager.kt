package com.morbistore.app.data

import android.content.Context
import android.content.SharedPreferences

class SessionManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("morbistore_prefs", Context.MODE_PRIVATE)

    var token: String?
        get() = prefs.getString("token", null)
        set(value) = prefs.edit().putString("token", value).apply()

    var username: String?
        get() = prefs.getString("username", null)
        set(value) = prefs.edit().putString("username", value).apply()

    // "system" | "light" | "dark"
    var themeMode: String
        get() = prefs.getString("theme_mode", "system") ?: "system"
        set(value) = prefs.edit().putString("theme_mode", value).apply()

    // "system" | "ru" | "en"
    var languageMode: String
        get() = prefs.getString("language_mode", "system") ?: "system"
        set(value) = prefs.edit().putString("language_mode", value).apply()

    var notificationsEnabled: Boolean
        get() = prefs.getBoolean("notifications_enabled", true)
        set(value) = prefs.edit().putBoolean("notifications_enabled", value).apply()

    fun isLoggedIn(): Boolean = token != null

    fun logout() {
        prefs.edit().remove("token").remove("username").apply()
    }

    fun authHeader(): String = "Bearer ${token ?: ""}"
}
