package com.morbistore.app.data

import android.content.Context
import android.content.res.Configuration
import java.util.Locale

object LocaleHelper {

    // mode: "system" | "ru" | "en"
    fun wrap(context: Context, mode: String): Context {
        if (mode == "system") return context
        val locale = Locale(mode)
        Locale.setDefault(locale)
        val config = Configuration(context.resources.configuration)
        config.setLocale(locale)
        return context.createConfigurationContext(config)
    }
}
