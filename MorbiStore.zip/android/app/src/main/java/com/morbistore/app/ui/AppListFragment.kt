package com.morbistore.app.ui

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.lifecycle.lifecycleScope
import com.morbistore.app.adapters.AppAdapter
import com.morbistore.app.data.ApiClient
import com.morbistore.app.databinding.FragmentAppListBinding
import kotlinx.coroutines.launch

class AppListFragment : Fragment() {

    private var _binding: FragmentAppListBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: AppAdapter
    private var tab: String = "all"
    private var currentSearch: String? = null

    companion object {
        private const val ARG_TAB = "arg_tab"
        fun newInstance(tab: String): AppListFragment {
            val f = AppListFragment()
            val b = Bundle()
            b.putString(ARG_TAB, tab)
            f.arguments = b
            return f
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tab = arguments?.getString(ARG_TAB) ?: "all"
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAppListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        adapter = AppAdapter(emptyList()) { app ->
            val intent = Intent(requireContext(), AppDetailActivity::class.java)
            intent.putExtra("app_id", app.id)
            startActivity(intent)
        }
        binding.recyclerView.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerView.adapter = adapter

        binding.swipeRefresh.setOnRefreshListener { loadApps() }
        loadApps()
    }

    // Вызывается из MainActivity при вводе текста в поиск
    fun search(query: String?) {
        currentSearch = query
        loadApps()
    }

    private fun loadApps() {
        binding.swipeRefresh.isRefreshing = true
        lifecycleScope.launch {
            try {
                val response = ApiClient.api.getApps(tab, currentSearch)
                if (response.isSuccessful) {
                    val list = response.body() ?: emptyList()
                    adapter.updateData(list)
                    binding.txtEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
                }
            } catch (e: Exception) {
                // Сервер недоступен — покажем пустой экран.
                // Проверь, что backend запущен и адрес в ApiClient.kt указан верно.
                binding.txtEmpty.visibility = View.VISIBLE
            } finally {
                binding.swipeRefresh.isRefreshing = false
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
