package com.morbistore.app.ui

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.morbistore.app.R
import com.morbistore.app.adapters.ReviewAdapter
import com.morbistore.app.adapters.ScreenshotAdapter
import com.morbistore.app.data.ApiClient
import com.morbistore.app.data.AppItem
import com.morbistore.app.data.ReviewRequest
import com.morbistore.app.data.SessionManager
import com.morbistore.app.databinding.ActivityAppDetailBinding
import com.morbistore.app.databinding.DialogAddReviewBinding
import kotlinx.coroutines.launch
import java.io.File

class AppDetailActivity : BaseActivity() {

    private lateinit var binding: ActivityAppDetailBinding
    private lateinit var session: SessionManager
    private var appId: Int = -1
    private var currentApp: AppItem? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAppDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        binding.toolbar.setNavigationOnClickListener { finish() }

        session = SessionManager(this)
        appId = intent.getIntExtra("app_id", -1)

        binding.recyclerScreenshots.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)

        binding.btnDownload.setOnClickListener { downloadAndInstall() }
        binding.btnAddReview.setOnClickListener { showAddReviewDialog() }

        loadDetail()
    }

    private fun loadDetail() {
        lifecycleScope.launch {
            try {
                val response = ApiClient.api.getAppDetail(appId)
                if (response.isSuccessful) {
                    val app = response.body() ?: return@launch
                    currentApp = app
                    bindApp(app)
                }
            } catch (e: Exception) {
                Toast.makeText(this@AppDetailActivity, "Ошибка загрузки", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun bindApp(app: AppItem) {
        binding.txtTitle.text = app.title
        binding.txtDeveloper.text = app.developer_name ?: ""
        binding.txtDescription.text = app.description ?: ""

        val iconUrl = app.icon_path?.let { ApiClient.BASE_URL + it }
        Glide.with(this).load(iconUrl).into(binding.imgIcon)

        app.screenshots?.let {
            binding.recyclerScreenshots.adapter = ScreenshotAdapter(it)
        }
        app.reviews?.let {
            binding.recyclerReviews.layoutManager = LinearLayoutManager(this)
            binding.recyclerReviews.adapter = ReviewAdapter(it)
        }
    }

    // Скачивание APK системным DownloadManager и запуск установки
    private fun downloadAndInstall() {
        val app = currentApp ?: return
        val url = ApiClient.BASE_URL + app.apk_path
        val fileName = "${app.title.replace(" ", "_")}.apk"

        lifecycleScope.launch {
            try { ApiClient.api.registerDownload(app.id) } catch (e: Exception) { /* не критично */ }
        }

        val request = DownloadManager.Request(Uri.parse(url))
            .setTitle(app.title)
            .setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, fileName)
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)

        val manager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val downloadId = manager.enqueue(request)

        Toast.makeText(this, getString(R.string.download) + "…", Toast.LENGTH_SHORT).show()

        // Открываем установщик после завершения скачивания
        val file = File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), fileName)
        Thread {
            var downloading = true
            while (downloading) {
                val cursor = manager.query(DownloadManager.Query().setFilterById(downloadId))
                if (cursor.moveToFirst()) {
                    val statusIndex = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS)
                    if (cursor.getInt(statusIndex) == DownloadManager.STATUS_SUCCESSFUL) {
                        downloading = false
                        runOnUiThread { installApk(file) }
                    }
                }
                cursor.close()
            }
        }.start()
    }

    private fun installApk(file: File) {
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
        }
        startActivity(intent)
    }

    private fun showAddReviewDialog() {
        if (!session.isLoggedIn()) {
            Toast.makeText(this, getString(R.string.login_required), Toast.LENGTH_SHORT).show()
            startActivity(Intent(this, LoginActivity::class.java))
            return
        }
        val dialogBinding = DialogAddReviewBinding.inflate(layoutInflater)
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(getString(R.string.add_review))
            .setView(dialogBinding.root)
            .setPositiveButton(getString(R.string.submit)) { _, _ ->
                val rating = dialogBinding.ratingBar.rating.toInt()
                val text = dialogBinding.editReviewText.text.toString()
                submitReview(rating, text)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun submitReview(rating: Int, text: String) {
        lifecycleScope.launch {
            try {
                val response = ApiClient.api.postReview(appId, session.authHeader(), ReviewRequest(rating, text))
                if (response.isSuccessful) {
                    Toast.makeText(this@AppDetailActivity, "Отзыв добавлен", Toast.LENGTH_SHORT).show()
                    loadDetail()
                }
            } catch (e: Exception) {
                Toast.makeText(this@AppDetailActivity, "Ошибка отправки отзыва", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
