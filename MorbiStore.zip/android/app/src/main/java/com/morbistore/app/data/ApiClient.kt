package com.morbistore.app.data

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object ApiClient {

    // !!! ГЛАВНАЯ НАСТРОЙКА !!!
    // Замени этот адрес на адрес своего сервера (IP или домен).
    // Пример для теста в локальной сети: "http://192.168.1.50:3000/"
    // Пример для сервера в интернете: "https://morbistore.ru/"
    const val BASE_URL = "http://10.0.2.2:3000/" // 10.0.2.2 = localhost компьютера, для эмулятора

    private val logging = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BASIC
    }

    private val client = OkHttpClient.Builder()
        .addInterceptor(logging)
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    val api: ApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)
    }
}
